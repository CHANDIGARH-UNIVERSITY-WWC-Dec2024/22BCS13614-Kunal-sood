export interface CulturalEvent {
  id: string;
  title: string;
  description: string;
  category: EventCategory;
  date: string;
  time: string;
  location: string;
  imageUrl: string;
  price: number | 'Free';
}

export type EventCategory = 
  | 'Festival'
  | 'Art'
  | 'Music'
  | 'Food'
  | 'Dance'
  | 'Theater'
  | 'Heritage';

export interface Filters {
  category: EventCategory | 'All';
  searchQuery: string;
  priceRange: number;
}