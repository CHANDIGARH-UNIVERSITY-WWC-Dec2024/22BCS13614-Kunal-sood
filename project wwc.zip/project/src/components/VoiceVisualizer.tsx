import React from 'react';

export default function VoiceVisualizer({ isListening }: { isListening: boolean }) {
  return (
    <div className="flex justify-center items-center gap-1 h-8">
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className={`w-1 bg-blue-500 rounded-full transition-all duration-150 ${
            isListening ? 'animate-pulse' : 'h-1'
          }`}
          style={{
            height: isListening ? `${Math.random() * 32}px` : '4px',
            animationDelay: `${i * 0.1}s`
          }}
        />
      ))}
    </div>
  );
}