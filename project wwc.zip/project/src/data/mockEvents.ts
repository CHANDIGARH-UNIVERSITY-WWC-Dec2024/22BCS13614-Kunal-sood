import { CulturalEvent } from '../types';

export const mockEvents: CulturalEvent[] = [
  {
    id: '1',
    title: 'Traditional Lantern Festival',
    description: 'Experience the magic of hundreds of lanterns illuminating the night sky while enjoying traditional performances and cuisine.',
    category: 'Festival',
    date: '2024-03-15',
    time: '18:00',
    location: 'Central Park',
    imageUrl: 'https://images.unsplash.com/photo-1582584158869-02b66257f214',
    price: 'Free'
  },
  {
    id: '2',
    title: 'Indigenous Art Exhibition',
    description: 'Discover the rich cultural heritage through contemporary indigenous artworks.',
    category: 'Art',
    date: '2024-03-20',
    time: '10:00',
    location: 'Metropolitan Museum',
    imageUrl: 'https://images.unsplash.com/photo-1561839561-b13bcfe95249',
    price: 15
  },
  {
    id: '3',
    title: 'World Music Concert',
    description: 'A fusion of traditional and modern musical performances from around the globe.',
    category: 'Music',
    date: '2024-03-25',
    time: '19:30',
    location: 'City Concert Hall',
    imageUrl: 'https://images.unsplash.com/photo-1511735111819-9a3f7709049c',
    price: 25
  },
  {
    id: '4',
    title: 'Cultural Food Festival',
    description: 'Taste authentic dishes from different cultures and learn about their culinary traditions.',
    category: 'Food',
    date: '2024-03-18',
    time: '11:00',
    location: 'Downtown Square',
    imageUrl: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1',
    price: 'Free'
  }
];