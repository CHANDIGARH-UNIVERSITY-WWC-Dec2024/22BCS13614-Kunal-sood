import React, { useState } from 'react';
import { HouseFeatures } from '../types';
import { Building2, Calendar, Home, Warehouse } from 'lucide-react';

const neighborhoods = ['North', 'South', 'East', 'West', 'Central'];
const buildingTypes = ['Single Family', 'Townhouse', 'Apartment', 'Condo'];
const houseStyles = ['1-Story', '2-Story', 'Split-Level', 'Ranch'];
const roofMaterials = ['Asphalt', 'Metal', 'Wood Shake', 'Slate'];

export default function PredictionForm({ 
  onPredict 
}: { 
  onPredict: (features: HouseFeatures) => void 
}) {
  const [features, setFeatures] = useState<HouseFeatures>({
    lotArea: 0,
    yearBuilt: 2000,
    totalRooms: 3,
    garageArea: 0,
    neighborhood: neighborhoods[0],
    buildingType: buildingTypes[0],
    houseStyle: houseStyles[0],
    roofMaterial: roofMaterials[0]
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onPredict(features);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            <div className="flex items-center gap-2">
              <Home className="w-4 h-4" />
              Lot Area (sq ft)
            </div>
          </label>
          <input
            type="number"
            value={features.lotArea}
            onChange={(e) => setFeatures({ ...features, lotArea: Number(e.target.value) })}
            className="w-full px-3 py-2 border rounded-md"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Year Built
            </div>
          </label>
          <input
            type="number"
            value={features.yearBuilt}
            onChange={(e) => setFeatures({ ...features, yearBuilt: Number(e.target.value) })}
            className="w-full px-3 py-2 border rounded-md"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              Total Rooms
            </div>
          </label>
          <input
            type="number"
            value={features.totalRooms}
            onChange={(e) => setFeatures({ ...features, totalRooms: Number(e.target.value) })}
            className="w-full px-3 py-2 border rounded-md"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            <div className="flex items-center gap-2">
              <Warehouse className="w-4 h-4" />
              Garage Area (sq ft)
            </div>
          </label>
          <input
            type="number"
            value={features.garageArea}
            onChange={(e) => setFeatures({ ...features, garageArea: Number(e.target.value) })}
            className="w-full px-3 py-2 border rounded-md"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">Neighborhood</label>
          <select
            value={features.neighborhood}
            onChange={(e) => setFeatures({ ...features, neighborhood: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
          >
            {neighborhoods.map((n) => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">Building Type</label>
          <select
            value={features.buildingType}
            onChange={(e) => setFeatures({ ...features, buildingType: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
          >
            {buildingTypes.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">House Style</label>
          <select
            value={features.houseStyle}
            onChange={(e) => setFeatures({ ...features, houseStyle: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
          >
            {houseStyles.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">Roof Material</label>
          <select
            value={features.roofMaterial}
            onChange={(e) => setFeatures({ ...features, roofMaterial: e.target.value })}
            className="w-full px-3 py-2 border rounded-md"
          >
            {roofMaterials.map((m) => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
        </div>
      </div>

      <button
        type="submit"
        className="w-full px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors"
      >
        Predict Price
      </button>
    </form>
  );
}