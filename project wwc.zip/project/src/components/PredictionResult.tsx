import React from 'react';
import { PredictionResult as PredictionResultType } from '../types';

export default function PredictionResult({ result }: { result: PredictionResultType | null }) {
  if (!result) return null;

  return (
    <div className="mt-8 p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Prediction Result</h2>
      <div className="space-y-4">
        <div>
          <p className="text-gray-600">Estimated Price:</p>
          <p className="text-3xl font-bold text-blue-600">
            ${result.predictedPrice.toLocaleString()}
          </p>
        </div>
        <div>
          <p className="text-gray-600">Confidence Score:</p>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div
              className="bg-blue-600 h-2.5 rounded-full"
              style={{ width: `${result.confidence * 100}%` }}
            ></div>
          </div>
          <p className="text-sm text-gray-500 mt-1">
            {(result.confidence * 100).toFixed(1)}% confidence in prediction
          </p>
        </div>
      </div>
    </div>
  );
}