import { Command } from './types';

export const commands: Command[] = [
  {
    trigger: "hello",
    response: "Hello! How can I help you today?"
  },
  {
    trigger: "what time is it",
    response: () => `It's ${new Date().toLocaleTimeString()}`,
  },
  {
    trigger: "what's the date",
    response: () => `Today is ${new Date().toLocaleDateString()}`,
  },
  {
    trigger: "who are you",
    response: "I'm your voice assistant, ready to help you with various tasks."
  },
  {
    trigger: "weather",
    response: "I'm sorry, I don't have access to weather data yet."
  },
  {
    trigger: "thank you",
    response: "You're welcome! Is there anything else I can help you with?"
  },
  {
    trigger: "goodbye",
    response: "Goodbye! Have a great day!"
  }
];