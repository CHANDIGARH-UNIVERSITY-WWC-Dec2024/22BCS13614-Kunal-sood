import React from 'react';

export default function TranscriptDisplay({ transcript }: { transcript: string }) {
  return (
    <div className="w-full max-w-lg bg-white/50 backdrop-blur-sm rounded-lg p-4 mt-4">
      <p className="text-gray-700 text-center">
        {transcript || "Waiting for voice input..."}
      </p>
    </div>
  );
}