import React from 'react';
import { Calendar, Clock, MapPin, Ticket } from 'lucide-react';
import { CulturalEvent } from '../types';

interface EventCardProps {
  event: CulturalEvent;
}

export default function EventCard({ event }: EventCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-[1.02]">
      <img 
        src={event.imageUrl} 
        alt={event.title}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-semibold text-gray-800">{event.title}</h3>
          <span className="px-2 py-1 text-sm rounded-full bg-blue-100 text-blue-800">
            {event.category}
          </span>
        </div>
        <p className="text-gray-600 mb-4 line-clamp-2">{event.description}</p>
        <div className="space-y-2 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span>{new Date(event.date).toLocaleDateString()}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            <span>{event.time}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            <span>{event.location}</span>
          </div>
          <div className="flex items-center gap-2">
            <Ticket className="w-4 h-4" />
            <span>{typeof event.price === 'number' ? `$${event.price}` : event.price}</span>
          </div>
        </div>
      </div>
    </div>
  );
}