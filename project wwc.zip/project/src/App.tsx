import React, { useState, useMemo } from 'react';
import { Globe } from 'lucide-react';
import { mockEvents } from './data/mockEvents';
import { Filters } from './types';
import EventCard from './components/EventCard';
import FilterBar from './components/FilterBar';

function App() {
  const [filters, setFilters] = useState<Filters>({
    category: 'All',
    searchQuery: '',
    priceRange: 100
  });

  const filteredEvents = useMemo(() => {
    return mockEvents.filter(event => {
      const matchesCategory = filters.category === 'All' || event.category === filters.category;
      const matchesSearch = event.title.toLowerCase().includes(filters.searchQuery.toLowerCase()) ||
                          event.description.toLowerCase().includes(filters.searchQuery.toLowerCase());
      const matchesPrice = event.price === 'Free' || 
                          (typeof event.price === 'number' && event.price <= filters.priceRange);
      
      return matchesCategory && matchesSearch && matchesPrice;
    });
  }, [filters]);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <Globe className="w-8 h-8 text-blue-500" />
            <h1 className="text-2xl font-bold text-gray-900">Cultural Experience Finder</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <FilterBar filters={filters} onFilterChange={setFilters} />
          </div>
          
          <div className="lg:col-span-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredEvents.length > 0 ? (
                filteredEvents.map(event => (
                  <EventCard key={event.id} event={event} />
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <p className="text-gray-500 text-lg">
                    No events found matching your criteria.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;