import { useState, useEffect, useCallback, useRef } from 'react';
import { commands } from '../commands';
import { VoiceState } from '../types';

export function useVoiceAssistant() {
  const [state, setState] = useState<VoiceState>({
    isListening: false,
    transcript: '',
    speaking: false,
  });

  // Use refs to maintain instance across renders
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const speechSynthesisRef = useRef<SpeechSynthesis | null>(null);

  // Initialize recognition instance once
  useEffect(() => {
    if (!recognitionRef.current) {
      recognitionRef.current = new (window.webkitSpeechRecognition || window.SpeechRecognition)();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
    }
    if (!speechSynthesisRef.current) {
      speechSynthesisRef.current = window.speechSynthesis;
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const speak = useCallback((text: string) => {
    if (!speechSynthesisRef.current) return;
    
    setState(prev => ({ ...prev, speaking: true }));
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.onend = () => setState(prev => ({ ...prev, speaking: false }));
    speechSynthesisRef.current.speak(utterance);
  }, []);

  const processCommand = useCallback((transcript: string) => {
    const command = commands.find(cmd => 
      transcript.toLowerCase().includes(cmd.trigger.toLowerCase())
    );

    if (command) {
      const response = typeof command.response === 'function' 
        ? command.response() 
        : command.response;
      speak(response);
      if (command.action) {
        command.action();
      }
    }
  }, [speak]);

  const toggleListening = useCallback(() => {
    if (!recognitionRef.current) return;

    setState(prev => {
      const newIsListening = !prev.isListening;
      if (newIsListening) {
        recognitionRef.current?.start();
      } else {
        recognitionRef.current?.stop();
      }
      return { ...prev, isListening: newIsListening };
    });
  }, []);

  useEffect(() => {
    if (!recognitionRef.current) return;

    recognitionRef.current.onresult = (event) => {
      const transcript = Array.from(event.results)
        .map(result => result[0].transcript)
        .join('');

      setState(prev => ({ ...prev, transcript }));

      if (event.results[event.results.length - 1].isFinal) {
        processCommand(transcript);
      }
    };

    recognitionRef.current.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
      setState(prev => ({ ...prev, isListening: false }));
    };
  }, [processCommand]);

  return {
    ...state,
    toggleListening,
    speak
  };
}